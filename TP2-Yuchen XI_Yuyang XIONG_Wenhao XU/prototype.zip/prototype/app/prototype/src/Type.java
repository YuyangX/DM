public enum Type {
	1,
	2
}