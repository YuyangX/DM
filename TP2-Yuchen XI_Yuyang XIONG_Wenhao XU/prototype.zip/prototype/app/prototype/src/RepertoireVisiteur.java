public class RepertoireVisiteur {

	private RDV[] listeRDV;
	private Walkin[] listeVisiteur;
	private int indexRDV;

	/**
	 * 
	 * @param rdv
	 */
	public Boolean addRDV(RDV rdv) {
		// TODO - implement RepertoireVisiteur.addRDV
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param walkin
	 */
	public Boolean addWalkin(Walkin walkin) {
		// TODO - implement RepertoireVisiteur.addWalkin
		throw new UnsupportedOperationException();
	}

	public Boolean removeRDV() {
		// TODO - implement RepertoireVisiteur.removeRDV
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param numéroDeReservation
	 */
	public RDV getRDV(String numéroDeReservation) {
		// TODO - implement RepertoireVisiteur.getRDV
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nom
	 * @param tel
	 */
	public Walkin getWalkin(String nom, String tel) {
		// TODO - implement RepertoireVisiteur.getWalkin
		throw new UnsupportedOperationException();
	}

	public RDV[] getRappel() {
		// TODO - implement RepertoireVisiteur.getRappel
		throw new UnsupportedOperationException();
	}

}