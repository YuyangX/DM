public class Date {

	private String annee;
	private String mois;
	private String jour;

	public String getAnnee() {
		return this.annee;
	}

	/**
	 * 
	 * @param Annee
	 */
	public void setAnnee(String Annee) {
		this.annee = Annee;
	}

	public String getMois() {
		return this.mois;
	}

	/**
	 * 
	 * @param Mois
	 */
	public void setMois(String Mois) {
		this.mois = Mois;
	}

	public String getJour() {
		return this.jour;
	}

	/**
	 * 
	 * @param Jour
	 */
	public void setJour(String Jour) {
		this.jour = Jour;
	}

}