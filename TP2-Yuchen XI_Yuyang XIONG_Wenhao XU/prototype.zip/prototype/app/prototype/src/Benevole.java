public class Benevole extends Equipier {

	private Date[] listDispo;

	public Date[] getList() {
		// TODO - implement Benevole.getList
		throw new UnsupportedOperationException();
	}

}