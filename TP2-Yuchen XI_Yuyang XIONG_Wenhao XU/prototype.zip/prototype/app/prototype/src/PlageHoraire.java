public class PlageHoraire extends Date {

	private String heure;

	public String getHeure() {
		return this.heure;
	}

	/**
	 * 
	 * @param Heure
	 */
	public void setHeure(String Heure) {
		this.heure = Heure;
	}

}