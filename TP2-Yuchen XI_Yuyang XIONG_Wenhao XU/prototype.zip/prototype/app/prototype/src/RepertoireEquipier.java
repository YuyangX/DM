public class RepertoireEquipier {

	private Employe[] employes;
	private Benevole[] benevoles;
	private int index;

	/**
	 * 
	 * @param code
	 */
	public Boolean supprimerBenevole(String code) {
		// TODO - implement RepertoireEquipier.supprimerBenevole
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param benevole
	 */
	public Boolean ajouterBenevole(Benevole benevole) {
		// TODO - implement RepertoireEquipier.ajouterBenevole
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param employe
	 */
	public Boolean ajouterEmploye(Employe employe) {
		// TODO - implement RepertoireEquipier.ajouterEmploye
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param codeIdentification
	 */
	public Benevole getBenevole(String codeIdentification) {
		// TODO - implement RepertoireEquipier.getBenevole
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param benevole
	 */
	public void modifierBenevole(Benevole benevole) {

	}

}