public class Menu {

	private int loggedUser;
	private Boolean isEmployé;
	private Controller controleurEquipier;
	private Controller controleurCompte;
	private Controller controleurBenevole;

	public void printBenevoleMenu() {
		// TODO - implement Menu.printBenevoleMenu
		throw new UnsupportedOperationException();
	}

	public void printEmployeMenu() {
		// TODO - implement Menu.printEmployeMenu
		throw new UnsupportedOperationException();
	}

	public void loginMenu() {
		// TODO - implement Menu.loginMenu
		throw new UnsupportedOperationException();
	}

	public void verifier() {
		// TODO - implement Menu.verifier
		throw new UnsupportedOperationException();
	}

	public void sponCal() {
		// TODO - implement Menu.sponCal
		throw new UnsupportedOperationException();
	}

	public void gererBene() {
		// TODO - implement Menu.gererBene
		throw new UnsupportedOperationException();
	}

	public void gererVisi() {
		// TODO - implement Menu.gererVisi
		throw new UnsupportedOperationException();
	}

	public void gererRDV() {
		// TODO - implement Menu.gererRDV
		throw new UnsupportedOperationException();
	}

	public void rappel() {
		// TODO - implement Menu.rappel
		throw new UnsupportedOperationException();
	}

	public void formulaire() {
		// TODO - implement Menu.formulaire
		throw new UnsupportedOperationException();
	}

	public void preuve() {
		// TODO - implement Menu.preuve
		throw new UnsupportedOperationException();
	}

	public void confirmerRDV() {
		// TODO - implement Menu.confirmerRDV
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param choix
	 */
	public void jugeBene(int choix) {
		// TODO - implement Menu.jugeBene
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param choix
	 */
	public void jugeVisi(int choix) {
		// TODO - implement Menu.jugeVisi
		throw new UnsupportedOperationException();
	}

	public void quit() {
		// TODO - implement Menu.quit
		throw new UnsupportedOperationException();
	}

}