public class Employe extends Equipier {
}