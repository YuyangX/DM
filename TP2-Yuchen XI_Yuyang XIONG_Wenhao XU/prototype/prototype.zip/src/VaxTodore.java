public class VaxTodore {

	public static void main(String[] args) {
		// TODO - implement VaxTodore.main
		throw new UnsupportedOperationException();
	}

}