public enum Vaccin {
	Moderna,
	Pfizer,
	AstraZeneca,
	Janssen
}