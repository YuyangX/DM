public interface Controller {

	/**
	 * 
	 * @param info
	 */
	Boolean isValid(String[] info);

}